AURA NOMA — Taylung

1. index.html ni GitHub repositoryga yuklang.
2. GitHub Pages -> Settings -> Pages -> Deploy from branch -> main/root.
3. Hosil bo‘lgan Pages linkini telefonda ham ochish mumkin.

Kalitlar:
- Ism: taylung
- Aura: +9999 yoki undan katta
- Ustoz: master shifu
- Keyin rasm yuklanadi va yakuniy ekran chiqadi.

Eslatma: bu demo rasmni brauzer ichida ko‘rsatadi, serverga yubormaydi. Agar rasmni sizga/administratorga haqiqatan yuborish kerak bo‘lsa, backend yoki fayl-storage ulash kerak.
